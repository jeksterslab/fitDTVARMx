library(testthat)
library(fitDTVARMx)

test_check("fitDTVARMx")

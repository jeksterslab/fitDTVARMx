.FitDTVAR <- function(data,
                      observed,
                      id,
                      beta_start = NULL,
                      beta_lbound = NULL,
                      beta_ubound = NULL,
                      psi_start = NULL,
                      psi_lbound = NULL,
                      psi_ubound = NULL,
                      psi_diag = TRUE,
                      try = 1000,
                      ncores = NULL) {
  k <- length(observed)
  idx <- seq_len(k)
  statenames <- paste0(
    "eta",
    idx
  )
  ids <- sort(
    unique(data[, id])
  )
  beta <- .FitDTVARBeta(
    k = k,
    statenames = statenames,
    beta_start = beta_start,
    beta_lbound = beta_lbound,
    beta_ubound = beta_ubound
  )
  gamma <- .FitDTVARGamma(k = k)
  lambda <- .FitDTVARLambda(
    k = k,
    observed = observed
  )
  kappa <- .FitDTVARKappa(k = k)
  psi <- .FitDTVARPsi(
    k = k,
    psi_start = psi_start,
    psi_lbound = psi_lbound,
    psi_ubound = psi_ubound,
    psi_diag = psi_diag
  )
  theta <- .FitDTVARTheta(
    k = k,
    observed = observed
  )
  mu0 <- .FitDTVARMu0(k = k)
  sigma0 <- .FitDTVARSigma0(k = k)
  x <- .FitDTVARX()
  par <- FALSE
  if (!is.null(ncores)) {
    ncores <- as.integer(ncores)
    if (ncores > 1) {
      par <- TRUE
    }
  }
  expectation <- OpenMx::mxExpectationStateSpace(
    A = "beta",
    B = "gamma",
    C = "lambda",
    D = "kappa",
    Q = "psi",
    R = "theta",
    x0 = "mu0",
    P0 = "sigma0",
    u = "x",
    dimnames = observed
  )
  if (par) {
    OpenMx::mxOption(
      key = "Number of Threads",
      value = 1
    )
    cl <- parallel::makeCluster(ncores)
    on.exit(
      parallel::stopCluster(cl = cl)
    )
    output <- parallel::parLapply(
      cl = cl,
      X = ids,
      fun = function(i) {
        model <- OpenMx::mxModel(
          model = "DTVAR",
          beta,
          gamma,
          lambda,
          kappa,
          psi,
          theta,
          mu0,
          sigma0,
          x,
          expectation,
          OpenMx::mxFitFunctionML(),
          OpenMx::mxData(
            observed = data[which(data[, id] == i), ],
            type = "raw"
          )
        )
        OpenMx::mxTryHard(
          model = model,
          extraTries = try
        )
      }
    )
  } else {
    output <- lapply(
      X = ids,
      FUN = function(i) {
        model <- OpenMx::mxModel(
          model = "DTVAR",
          beta,
          gamma,
          lambda,
          kappa,
          psi,
          theta,
          mu0,
          sigma0,
          x,
          expectation,
          OpenMx::mxFitFunctionML(),
          OpenMx::mxData(
            observed = data[which(data[, id] == i), ],
            type = "raw"
          )
        )
        OpenMx::mxTryHard(
          model = model,
          extraTries = try
        )
      }
    )
  }
  return(output)
}
